# -*- coding: utf-8 -*-
# setup.py
from distutils.core import setup

setup(
    name="daemon",
    version="1.1",
    py_modules=['daemon']
)
